import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or '7110c8ae51a4b5af97be6534caef90e4bb9bdcb3380af008f90b23a5d1616bf319bc298105da20fe'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'rooT12345-'
    MYSQL_DB = 'neo3'
    
    # Configuración de la URI para SQLAlchemy
    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Configuración del correo
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'unop73416@gmail.com'  # Cambia esto por tu correo
    MAIL_PASSWORD = 'PruebaUno123_'          # Cambia esto por tu contraseña
    MAIL_DEFAULT_SENDER = 'unop73416@gmail.com'  # Cambia esto por tu correo
