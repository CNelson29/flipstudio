from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_mail import Message
from datetime import datetime
from app import db, mail
from app.models import Reserva, Servicio

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/reservar', methods=['GET', 'POST'])
def reservar():
    if request.method == 'POST':
        fecha = request.form['fecha']
        hora_inicio = request.form['hora_inicio']
        
        nueva_reserva = Reserva(fecha=fecha, hora_inicio=hora_inicio)
        db.session.add(nueva_reserva)
        db.session.commit()
        
        flash('Reserva realizada con éxito. Te hemos enviado un correo de confirmación.')
        return redirect(url_for('main.index'))
    return render_template('reservar.html', reservas=Reserva.query.all())

@main.route('/servicios')
def servicios():
    return render_template('servicios.html', servicios=Servicio.query.all())

@main.route('/pago/<int:servicio_id>', methods=['GET', 'POST'])
def pago(servicio_id):
    servicio = Servicio.query.get_or_404(servicio_id)
    if request.method == 'POST':
        # Aquí agregas la lógica de pago, por ejemplo, con una API de pago como MercadoPago
        flash('Pago realizado con éxito.')
        return redirect(url_for('main.index'))
    return render_template('pago.html', servicio=servicio)
