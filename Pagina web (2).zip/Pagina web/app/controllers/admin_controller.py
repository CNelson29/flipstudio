from flask import Blueprint, render_template, request, redirect, url_for, flash
from ..models import db, Servicio

admin = Blueprint('admin', __name__)

@admin.route('/admin')
def admin_panel():
    servicios = Servicio.query.all()  # Obtén todos los servicios
    print(servicios)  # Agrega esta línea para depurar
    return render_template('admin.html', servicios=servicios)

@admin.route('/admin/modificar_servicio/<int:servicio_id>', methods=['GET', 'POST'])
def modificar_servicio(servicio_id):
    servicio = Servicio.query.get_or_404(servicio_id)  # Obtener el servicio o 404 si no existe
    if request.method == 'POST':
        servicio.nombre = request.form['nombre']
        servicio.precio = request.form['precio']
        db.session.commit()  # Guardar cambios en la base de datos
        flash('Servicio actualizado con éxito.')  # Mensaje de éxito
        return redirect(url_for('admin.admin_panel'))  # Redirigir al panel de administración
    return render_template('modificar_servicio.html', servicio=servicio)  # Mostrar formulario de edición
