// static/js/scripts.js
document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM completamente cargado y analizado');
    
    // Aquí puedes agregar más lógica de JavaScript
});
