from flask import Flask
from flask_mail import Mail
from flask_sqlalchemy import SQLAlchemy
from app.models import db
# Instancias de extensiones


mail = Mail()

def create_app():
    app = Flask(__name__)
    app.secret_key = '7110c8ae51a4b5af97be6534caef90e4bb9bdcb3380af008f90b23a5d1616bf319bc298105da20fe'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:rooT12345-@localhost/neo3'  # Ajusta según tu archivo de configuración

    # Inicializa las extensiones
    db.init_app(app)
    mail.init_app(app)

    # Registra los blueprints
    from app.controllers.main_controller import main
    from app.controllers.admin_controller import admin
    app.register_blueprint(main)
    app.register_blueprint(admin)

    return app
